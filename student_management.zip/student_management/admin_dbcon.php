<?php 
$hostname = "localhost";
$usernamex = "root";
$password = "";
$database_name = "student_manage";
$db_con=mysqli_connect($hostname , $usernamex , $password , $database_name);

?>